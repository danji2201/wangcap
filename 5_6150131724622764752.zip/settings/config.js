module.exports = {
  BOT_TOKEN: "8489491640:AAF32oUMgfCdxPtVkHn4p9hkQUSpLlyOS-s",
  allowedDevelopers: ['7002733445'], // ID MU
};