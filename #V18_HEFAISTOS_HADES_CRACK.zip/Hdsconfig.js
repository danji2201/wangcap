module.exports = {
      BOT_TOKEN: "8238559190:AAGzuZUfJYqM2RyqkPumaSdiRJe6RRR6aMA",
  OWNER_ID: ["8188993048"]
};

/*
[ Hallo Untuk Semua Para Pengguna HEFAISTOS HADES ]

┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
┃〢 Developer¹ : @MsLozz
┃〢 Developer² : @Gabrieltzyproooool
┃〢 Support : @MiUNNst
┃〢 Version : 18.0
┃〢 Nᴏᴛᴇ : THANKS TO YOU BUYYING THIS IS SCRIPT
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

THE SUPPORT THIS SCRIPT🔥🍂💱🍷❇️🍁☠️🤖🥀🎭
*/